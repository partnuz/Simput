<?php
return array (
  0 => 
  array (
    'key' => 'ABeeZee',
    'val' => 'ABeeZee',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  1 => 
  array (
    'key' => 'Abel',
    'val' => 'Abel',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  2 => 
  array (
    'key' => 'Abril Fatface',
    'val' => 'Abril Fatface',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  3 => 
  array (
    'key' => 'Aclonica',
    'val' => 'Aclonica',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  4 => 
  array (
    'key' => 'Acme',
    'val' => 'Acme',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  5 => 
  array (
    'key' => 'Actor',
    'val' => 'Actor',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  6 => 
  array (
    'key' => 'Adamina',
    'val' => 'Adamina',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  7 => 
  array (
    'key' => 'Advent Pro',
    'val' => 'Advent Pro',
    'weight' => 
    array (
      0 => '100',
      1 => '200',
      2 => '300',
      3 => 'regular',
      4 => '500',
      5 => '600',
      6 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
    ),
  ),
  8 => 
  array (
    'key' => 'Aguafina Script',
    'val' => 'Aguafina Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  9 => 
  array (
    'key' => 'Akronim',
    'val' => 'Akronim',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  10 => 
  array (
    'key' => 'Aladin',
    'val' => 'Aladin',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  11 => 
  array (
    'key' => 'Aldrich',
    'val' => 'Aldrich',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  12 => 
  array (
    'key' => 'Alef',
    'val' => 'Alef',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  13 => 
  array (
    'key' => 'Alegreya',
    'val' => 'Alegreya',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  14 => 
  array (
    'key' => 'Alegreya SC',
    'val' => 'Alegreya SC',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  15 => 
  array (
    'key' => 'Alegreya Sans',
    'val' => 'Alegreya Sans',
    'weight' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '500',
      7 => '500italic',
      8 => '700',
      9 => '700italic',
      10 => '800',
      11 => '800italic',
      12 => '900',
      13 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'vietnamese',
    ),
  ),
  16 => 
  array (
    'key' => 'Alegreya Sans SC',
    'val' => 'Alegreya Sans SC',
    'weight' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '500',
      7 => '500italic',
      8 => '700',
      9 => '700italic',
      10 => '800',
      11 => '800italic',
      12 => '900',
      13 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'vietnamese',
    ),
  ),
  17 => 
  array (
    'key' => 'Alex Brush',
    'val' => 'Alex Brush',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  18 => 
  array (
    'key' => 'Alfa Slab One',
    'val' => 'Alfa Slab One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  19 => 
  array (
    'key' => 'Alice',
    'val' => 'Alice',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  20 => 
  array (
    'key' => 'Alike',
    'val' => 'Alike',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  21 => 
  array (
    'key' => 'Alike Angular',
    'val' => 'Alike Angular',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  22 => 
  array (
    'key' => 'Allan',
    'val' => 'Allan',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  23 => 
  array (
    'key' => 'Allerta',
    'val' => 'Allerta',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  24 => 
  array (
    'key' => 'Allerta Stencil',
    'val' => 'Allerta Stencil',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  25 => 
  array (
    'key' => 'Allura',
    'val' => 'Allura',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  26 => 
  array (
    'key' => 'Almendra',
    'val' => 'Almendra',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  27 => 
  array (
    'key' => 'Almendra Display',
    'val' => 'Almendra Display',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  28 => 
  array (
    'key' => 'Almendra SC',
    'val' => 'Almendra SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  29 => 
  array (
    'key' => 'Amarante',
    'val' => 'Amarante',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  30 => 
  array (
    'key' => 'Amaranth',
    'val' => 'Amaranth',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  31 => 
  array (
    'key' => 'Amatic SC',
    'val' => 'Amatic SC',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  32 => 
  array (
    'key' => 'Amethysta',
    'val' => 'Amethysta',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  33 => 
  array (
    'key' => 'Anaheim',
    'val' => 'Anaheim',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  34 => 
  array (
    'key' => 'Andada',
    'val' => 'Andada',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  35 => 
  array (
    'key' => 'Andika',
    'val' => 'Andika',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  36 => 
  array (
    'key' => 'Angkor',
    'val' => 'Angkor',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  37 => 
  array (
    'key' => 'Annie Use Your Telescope',
    'val' => 'Annie Use Your Telescope',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  38 => 
  array (
    'key' => 'Anonymous Pro',
    'val' => 'Anonymous Pro',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
    ),
  ),
  39 => 
  array (
    'key' => 'Antic',
    'val' => 'Antic',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  40 => 
  array (
    'key' => 'Antic Didone',
    'val' => 'Antic Didone',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  41 => 
  array (
    'key' => 'Antic Slab',
    'val' => 'Antic Slab',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  42 => 
  array (
    'key' => 'Anton',
    'val' => 'Anton',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  43 => 
  array (
    'key' => 'Arapey',
    'val' => 'Arapey',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  44 => 
  array (
    'key' => 'Arbutus',
    'val' => 'Arbutus',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  45 => 
  array (
    'key' => 'Arbutus Slab',
    'val' => 'Arbutus Slab',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  46 => 
  array (
    'key' => 'Architects Daughter',
    'val' => 'Architects Daughter',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  47 => 
  array (
    'key' => 'Archivo Black',
    'val' => 'Archivo Black',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  48 => 
  array (
    'key' => 'Archivo Narrow',
    'val' => 'Archivo Narrow',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  49 => 
  array (
    'key' => 'Arimo',
    'val' => 'Arimo',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
    ),
  ),
  50 => 
  array (
    'key' => 'Arizonia',
    'val' => 'Arizonia',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  51 => 
  array (
    'key' => 'Armata',
    'val' => 'Armata',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  52 => 
  array (
    'key' => 'Artifika',
    'val' => 'Artifika',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  53 => 
  array (
    'key' => 'Arvo',
    'val' => 'Arvo',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  54 => 
  array (
    'key' => 'Asap',
    'val' => 'Asap',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  55 => 
  array (
    'key' => 'Asset',
    'val' => 'Asset',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  56 => 
  array (
    'key' => 'Astloch',
    'val' => 'Astloch',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  57 => 
  array (
    'key' => 'Asul',
    'val' => 'Asul',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  58 => 
  array (
    'key' => 'Atomic Age',
    'val' => 'Atomic Age',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  59 => 
  array (
    'key' => 'Aubrey',
    'val' => 'Aubrey',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  60 => 
  array (
    'key' => 'Audiowide',
    'val' => 'Audiowide',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  61 => 
  array (
    'key' => 'Autour One',
    'val' => 'Autour One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  62 => 
  array (
    'key' => 'Average',
    'val' => 'Average',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  63 => 
  array (
    'key' => 'Average Sans',
    'val' => 'Average Sans',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  64 => 
  array (
    'key' => 'Averia Gruesa Libre',
    'val' => 'Averia Gruesa Libre',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  65 => 
  array (
    'key' => 'Averia Libre',
    'val' => 'Averia Libre',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  66 => 
  array (
    'key' => 'Averia Sans Libre',
    'val' => 'Averia Sans Libre',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  67 => 
  array (
    'key' => 'Averia Serif Libre',
    'val' => 'Averia Serif Libre',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  68 => 
  array (
    'key' => 'Bad Script',
    'val' => 'Bad Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'cyrillic',
    ),
  ),
  69 => 
  array (
    'key' => 'Balthazar',
    'val' => 'Balthazar',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  70 => 
  array (
    'key' => 'Bangers',
    'val' => 'Bangers',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  71 => 
  array (
    'key' => 'Basic',
    'val' => 'Basic',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  72 => 
  array (
    'key' => 'Battambang',
    'val' => 'Battambang',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  73 => 
  array (
    'key' => 'Baumans',
    'val' => 'Baumans',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  74 => 
  array (
    'key' => 'Bayon',
    'val' => 'Bayon',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  75 => 
  array (
    'key' => 'Belgrano',
    'val' => 'Belgrano',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  76 => 
  array (
    'key' => 'Belleza',
    'val' => 'Belleza',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  77 => 
  array (
    'key' => 'BenchNine',
    'val' => 'BenchNine',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  78 => 
  array (
    'key' => 'Bentham',
    'val' => 'Bentham',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  79 => 
  array (
    'key' => 'Berkshire Swash',
    'val' => 'Berkshire Swash',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  80 => 
  array (
    'key' => 'Bevan',
    'val' => 'Bevan',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  81 => 
  array (
    'key' => 'Bigelow Rules',
    'val' => 'Bigelow Rules',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  82 => 
  array (
    'key' => 'Bigshot One',
    'val' => 'Bigshot One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  83 => 
  array (
    'key' => 'Bilbo',
    'val' => 'Bilbo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  84 => 
  array (
    'key' => 'Bilbo Swash Caps',
    'val' => 'Bilbo Swash Caps',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  85 => 
  array (
    'key' => 'Bitter',
    'val' => 'Bitter',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  86 => 
  array (
    'key' => 'Black Ops One',
    'val' => 'Black Ops One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  87 => 
  array (
    'key' => 'Bokor',
    'val' => 'Bokor',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  88 => 
  array (
    'key' => 'Bonbon',
    'val' => 'Bonbon',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  89 => 
  array (
    'key' => 'Boogaloo',
    'val' => 'Boogaloo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  90 => 
  array (
    'key' => 'Bowlby One',
    'val' => 'Bowlby One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  91 => 
  array (
    'key' => 'Bowlby One SC',
    'val' => 'Bowlby One SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  92 => 
  array (
    'key' => 'Brawler',
    'val' => 'Brawler',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  93 => 
  array (
    'key' => 'Bree Serif',
    'val' => 'Bree Serif',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  94 => 
  array (
    'key' => 'Bubblegum Sans',
    'val' => 'Bubblegum Sans',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  95 => 
  array (
    'key' => 'Bubbler One',
    'val' => 'Bubbler One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  96 => 
  array (
    'key' => 'Buda',
    'val' => 'Buda',
    'weight' => 
    array (
      0 => '300',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  97 => 
  array (
    'key' => 'Buenard',
    'val' => 'Buenard',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  98 => 
  array (
    'key' => 'Butcherman',
    'val' => 'Butcherman',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  99 => 
  array (
    'key' => 'Butterfly Kids',
    'val' => 'Butterfly Kids',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  100 => 
  array (
    'key' => 'Cabin',
    'val' => 'Cabin',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '500',
      3 => '500italic',
      4 => '600',
      5 => '600italic',
      6 => '700',
      7 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  101 => 
  array (
    'key' => 'Cabin Condensed',
    'val' => 'Cabin Condensed',
    'weight' => 
    array (
      0 => 'regular',
      1 => '500',
      2 => '600',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  102 => 
  array (
    'key' => 'Cabin Sketch',
    'val' => 'Cabin Sketch',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  103 => 
  array (
    'key' => 'Caesar Dressing',
    'val' => 'Caesar Dressing',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  104 => 
  array (
    'key' => 'Cagliostro',
    'val' => 'Cagliostro',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  105 => 
  array (
    'key' => 'Calligraffitti',
    'val' => 'Calligraffitti',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  106 => 
  array (
    'key' => 'Cambay',
    'val' => 'Cambay',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  107 => 
  array (
    'key' => 'Cambo',
    'val' => 'Cambo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  108 => 
  array (
    'key' => 'Candal',
    'val' => 'Candal',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  109 => 
  array (
    'key' => 'Cantarell',
    'val' => 'Cantarell',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  110 => 
  array (
    'key' => 'Cantata One',
    'val' => 'Cantata One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  111 => 
  array (
    'key' => 'Cantora One',
    'val' => 'Cantora One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  112 => 
  array (
    'key' => 'Capriola',
    'val' => 'Capriola',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  113 => 
  array (
    'key' => 'Cardo',
    'val' => 'Cardo',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'greek-ext',
    ),
  ),
  114 => 
  array (
    'key' => 'Carme',
    'val' => 'Carme',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  115 => 
  array (
    'key' => 'Carrois Gothic',
    'val' => 'Carrois Gothic',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  116 => 
  array (
    'key' => 'Carrois Gothic SC',
    'val' => 'Carrois Gothic SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  117 => 
  array (
    'key' => 'Carter One',
    'val' => 'Carter One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  118 => 
  array (
    'key' => 'Caudex',
    'val' => 'Caudex',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'greek-ext',
    ),
  ),
  119 => 
  array (
    'key' => 'Cedarville Cursive',
    'val' => 'Cedarville Cursive',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  120 => 
  array (
    'key' => 'Ceviche One',
    'val' => 'Ceviche One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  121 => 
  array (
    'key' => 'Changa One',
    'val' => 'Changa One',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  122 => 
  array (
    'key' => 'Chango',
    'val' => 'Chango',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  123 => 
  array (
    'key' => 'Chau Philomene One',
    'val' => 'Chau Philomene One',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  124 => 
  array (
    'key' => 'Chela One',
    'val' => 'Chela One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  125 => 
  array (
    'key' => 'Chelsea Market',
    'val' => 'Chelsea Market',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  126 => 
  array (
    'key' => 'Chenla',
    'val' => 'Chenla',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  127 => 
  array (
    'key' => 'Cherry Cream Soda',
    'val' => 'Cherry Cream Soda',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  128 => 
  array (
    'key' => 'Cherry Swash',
    'val' => 'Cherry Swash',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  129 => 
  array (
    'key' => 'Chewy',
    'val' => 'Chewy',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  130 => 
  array (
    'key' => 'Chicle',
    'val' => 'Chicle',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  131 => 
  array (
    'key' => 'Chivo',
    'val' => 'Chivo',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '900',
      3 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  132 => 
  array (
    'key' => 'Cinzel',
    'val' => 'Cinzel',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  133 => 
  array (
    'key' => 'Cinzel Decorative',
    'val' => 'Cinzel Decorative',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  134 => 
  array (
    'key' => 'Clicker Script',
    'val' => 'Clicker Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  135 => 
  array (
    'key' => 'Coda',
    'val' => 'Coda',
    'weight' => 
    array (
      0 => 'regular',
      1 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  136 => 
  array (
    'key' => 'Coda Caption',
    'val' => 'Coda Caption',
    'weight' => 
    array (
      0 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  137 => 
  array (
    'key' => 'Codystar',
    'val' => 'Codystar',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  138 => 
  array (
    'key' => 'Combo',
    'val' => 'Combo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  139 => 
  array (
    'key' => 'Comfortaa',
    'val' => 'Comfortaa',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'cyrillic-ext',
    ),
  ),
  140 => 
  array (
    'key' => 'Coming Soon',
    'val' => 'Coming Soon',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  141 => 
  array (
    'key' => 'Concert One',
    'val' => 'Concert One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  142 => 
  array (
    'key' => 'Condiment',
    'val' => 'Condiment',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  143 => 
  array (
    'key' => 'Content',
    'val' => 'Content',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  144 => 
  array (
    'key' => 'Contrail One',
    'val' => 'Contrail One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  145 => 
  array (
    'key' => 'Convergence',
    'val' => 'Convergence',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  146 => 
  array (
    'key' => 'Cookie',
    'val' => 'Cookie',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  147 => 
  array (
    'key' => 'Copse',
    'val' => 'Copse',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  148 => 
  array (
    'key' => 'Corben',
    'val' => 'Corben',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  149 => 
  array (
    'key' => 'Courgette',
    'val' => 'Courgette',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  150 => 
  array (
    'key' => 'Cousine',
    'val' => 'Cousine',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
    ),
  ),
  151 => 
  array (
    'key' => 'Coustard',
    'val' => 'Coustard',
    'weight' => 
    array (
      0 => 'regular',
      1 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  152 => 
  array (
    'key' => 'Covered By Your Grace',
    'val' => 'Covered By Your Grace',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  153 => 
  array (
    'key' => 'Crafty Girls',
    'val' => 'Crafty Girls',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  154 => 
  array (
    'key' => 'Creepster',
    'val' => 'Creepster',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  155 => 
  array (
    'key' => 'Crete Round',
    'val' => 'Crete Round',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  156 => 
  array (
    'key' => 'Crimson Text',
    'val' => 'Crimson Text',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '600',
      3 => '600italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  157 => 
  array (
    'key' => 'Croissant One',
    'val' => 'Croissant One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  158 => 
  array (
    'key' => 'Crushed',
    'val' => 'Crushed',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  159 => 
  array (
    'key' => 'Cuprum',
    'val' => 'Cuprum',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  160 => 
  array (
    'key' => 'Cutive',
    'val' => 'Cutive',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  161 => 
  array (
    'key' => 'Cutive Mono',
    'val' => 'Cutive Mono',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  162 => 
  array (
    'key' => 'Damion',
    'val' => 'Damion',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  163 => 
  array (
    'key' => 'Dancing Script',
    'val' => 'Dancing Script',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  164 => 
  array (
    'key' => 'Dangrek',
    'val' => 'Dangrek',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  165 => 
  array (
    'key' => 'Dawning of a New Day',
    'val' => 'Dawning of a New Day',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  166 => 
  array (
    'key' => 'Days One',
    'val' => 'Days One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  167 => 
  array (
    'key' => 'Dekko',
    'val' => 'Dekko',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  168 => 
  array (
    'key' => 'Delius',
    'val' => 'Delius',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  169 => 
  array (
    'key' => 'Delius Swash Caps',
    'val' => 'Delius Swash Caps',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  170 => 
  array (
    'key' => 'Delius Unicase',
    'val' => 'Delius Unicase',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  171 => 
  array (
    'key' => 'Della Respira',
    'val' => 'Della Respira',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  172 => 
  array (
    'key' => 'Denk One',
    'val' => 'Denk One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  173 => 
  array (
    'key' => 'Devonshire',
    'val' => 'Devonshire',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  174 => 
  array (
    'key' => 'Dhurjati',
    'val' => 'Dhurjati',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  175 => 
  array (
    'key' => 'Didact Gothic',
    'val' => 'Didact Gothic',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'cyrillic-ext',
    ),
  ),
  176 => 
  array (
    'key' => 'Diplomata',
    'val' => 'Diplomata',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  177 => 
  array (
    'key' => 'Diplomata SC',
    'val' => 'Diplomata SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  178 => 
  array (
    'key' => 'Domine',
    'val' => 'Domine',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  179 => 
  array (
    'key' => 'Donegal One',
    'val' => 'Donegal One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  180 => 
  array (
    'key' => 'Doppio One',
    'val' => 'Doppio One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  181 => 
  array (
    'key' => 'Dorsa',
    'val' => 'Dorsa',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  182 => 
  array (
    'key' => 'Dosis',
    'val' => 'Dosis',
    'weight' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => '500',
      4 => '600',
      5 => '700',
      6 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  183 => 
  array (
    'key' => 'Dr Sugiyama',
    'val' => 'Dr Sugiyama',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  184 => 
  array (
    'key' => 'Droid Sans',
    'val' => 'Droid Sans',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  185 => 
  array (
    'key' => 'Droid Sans Mono',
    'val' => 'Droid Sans Mono',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  186 => 
  array (
    'key' => 'Droid Serif',
    'val' => 'Droid Serif',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  187 => 
  array (
    'key' => 'Duru Sans',
    'val' => 'Duru Sans',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  188 => 
  array (
    'key' => 'Dynalight',
    'val' => 'Dynalight',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  189 => 
  array (
    'key' => 'EB Garamond',
    'val' => 'EB Garamond',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'vietnamese',
      4 => 'cyrillic-ext',
    ),
  ),
  190 => 
  array (
    'key' => 'Eagle Lake',
    'val' => 'Eagle Lake',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  191 => 
  array (
    'key' => 'Eater',
    'val' => 'Eater',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  192 => 
  array (
    'key' => 'Economica',
    'val' => 'Economica',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  193 => 
  array (
    'key' => 'Ek Mukta',
    'val' => 'Ek Mukta',
    'weight' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => '500',
      4 => '600',
      5 => '700',
      6 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  194 => 
  array (
    'key' => 'Electrolize',
    'val' => 'Electrolize',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  195 => 
  array (
    'key' => 'Elsie',
    'val' => 'Elsie',
    'weight' => 
    array (
      0 => 'regular',
      1 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  196 => 
  array (
    'key' => 'Elsie Swash Caps',
    'val' => 'Elsie Swash Caps',
    'weight' => 
    array (
      0 => 'regular',
      1 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  197 => 
  array (
    'key' => 'Emblema One',
    'val' => 'Emblema One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  198 => 
  array (
    'key' => 'Emilys Candy',
    'val' => 'Emilys Candy',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  199 => 
  array (
    'key' => 'Engagement',
    'val' => 'Engagement',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  200 => 
  array (
    'key' => 'Englebert',
    'val' => 'Englebert',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  201 => 
  array (
    'key' => 'Enriqueta',
    'val' => 'Enriqueta',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  202 => 
  array (
    'key' => 'Erica One',
    'val' => 'Erica One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  203 => 
  array (
    'key' => 'Esteban',
    'val' => 'Esteban',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  204 => 
  array (
    'key' => 'Euphoria Script',
    'val' => 'Euphoria Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  205 => 
  array (
    'key' => 'Ewert',
    'val' => 'Ewert',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  206 => 
  array (
    'key' => 'Exo',
    'val' => 'Exo',
    'weight' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '200',
      3 => '200italic',
      4 => '300',
      5 => '300italic',
      6 => 'regular',
      7 => 'italic',
      8 => '500',
      9 => '500italic',
      10 => '600',
      11 => '600italic',
      12 => '700',
      13 => '700italic',
      14 => '800',
      15 => '800italic',
      16 => '900',
      17 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  207 => 
  array (
    'key' => 'Exo 2',
    'val' => 'Exo 2',
    'weight' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '200',
      3 => '200italic',
      4 => '300',
      5 => '300italic',
      6 => 'regular',
      7 => 'italic',
      8 => '500',
      9 => '500italic',
      10 => '600',
      11 => '600italic',
      12 => '700',
      13 => '700italic',
      14 => '800',
      15 => '800italic',
      16 => '900',
      17 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  208 => 
  array (
    'key' => 'Expletus Sans',
    'val' => 'Expletus Sans',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '500',
      3 => '500italic',
      4 => '600',
      5 => '600italic',
      6 => '700',
      7 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  209 => 
  array (
    'key' => 'Fanwood Text',
    'val' => 'Fanwood Text',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  210 => 
  array (
    'key' => 'Fascinate',
    'val' => 'Fascinate',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  211 => 
  array (
    'key' => 'Fascinate Inline',
    'val' => 'Fascinate Inline',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  212 => 
  array (
    'key' => 'Faster One',
    'val' => 'Faster One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  213 => 
  array (
    'key' => 'Fasthand',
    'val' => 'Fasthand',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  214 => 
  array (
    'key' => 'Fauna One',
    'val' => 'Fauna One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  215 => 
  array (
    'key' => 'Federant',
    'val' => 'Federant',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  216 => 
  array (
    'key' => 'Federo',
    'val' => 'Federo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  217 => 
  array (
    'key' => 'Felipa',
    'val' => 'Felipa',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  218 => 
  array (
    'key' => 'Fenix',
    'val' => 'Fenix',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  219 => 
  array (
    'key' => 'Finger Paint',
    'val' => 'Finger Paint',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  220 => 
  array (
    'key' => 'Fira Mono',
    'val' => 'Fira Mono',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'cyrillic-ext',
    ),
  ),
  221 => 
  array (
    'key' => 'Fira Sans',
    'val' => 'Fira Sans',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '500',
      5 => '500italic',
      6 => '700',
      7 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'cyrillic-ext',
    ),
  ),
  222 => 
  array (
    'key' => 'Fjalla One',
    'val' => 'Fjalla One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  223 => 
  array (
    'key' => 'Fjord One',
    'val' => 'Fjord One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  224 => 
  array (
    'key' => 'Flamenco',
    'val' => 'Flamenco',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  225 => 
  array (
    'key' => 'Flavors',
    'val' => 'Flavors',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  226 => 
  array (
    'key' => 'Fondamento',
    'val' => 'Fondamento',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  227 => 
  array (
    'key' => 'Fontdiner Swanky',
    'val' => 'Fontdiner Swanky',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  228 => 
  array (
    'key' => 'Forum',
    'val' => 'Forum',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  229 => 
  array (
    'key' => 'Francois One',
    'val' => 'Francois One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  230 => 
  array (
    'key' => 'Freckle Face',
    'val' => 'Freckle Face',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  231 => 
  array (
    'key' => 'Fredericka the Great',
    'val' => 'Fredericka the Great',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  232 => 
  array (
    'key' => 'Fredoka One',
    'val' => 'Fredoka One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  233 => 
  array (
    'key' => 'Freehand',
    'val' => 'Freehand',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  234 => 
  array (
    'key' => 'Fresca',
    'val' => 'Fresca',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  235 => 
  array (
    'key' => 'Frijole',
    'val' => 'Frijole',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  236 => 
  array (
    'key' => 'Fruktur',
    'val' => 'Fruktur',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  237 => 
  array (
    'key' => 'Fugaz One',
    'val' => 'Fugaz One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  238 => 
  array (
    'key' => 'GFS Didot',
    'val' => 'GFS Didot',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'greek',
    ),
  ),
  239 => 
  array (
    'key' => 'GFS Neohellenic',
    'val' => 'GFS Neohellenic',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
    ),
  ),
  240 => 
  array (
    'key' => 'Gabriela',
    'val' => 'Gabriela',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  241 => 
  array (
    'key' => 'Gafata',
    'val' => 'Gafata',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  242 => 
  array (
    'key' => 'Galdeano',
    'val' => 'Galdeano',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  243 => 
  array (
    'key' => 'Galindo',
    'val' => 'Galindo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  244 => 
  array (
    'key' => 'Gentium Basic',
    'val' => 'Gentium Basic',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  245 => 
  array (
    'key' => 'Gentium Book Basic',
    'val' => 'Gentium Book Basic',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  246 => 
  array (
    'key' => 'Geo',
    'val' => 'Geo',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  247 => 
  array (
    'key' => 'Geostar',
    'val' => 'Geostar',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  248 => 
  array (
    'key' => 'Geostar Fill',
    'val' => 'Geostar Fill',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  249 => 
  array (
    'key' => 'Germania One',
    'val' => 'Germania One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  250 => 
  array (
    'key' => 'Gidugu',
    'val' => 'Gidugu',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  251 => 
  array (
    'key' => 'Gilda Display',
    'val' => 'Gilda Display',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  252 => 
  array (
    'key' => 'Give You Glory',
    'val' => 'Give You Glory',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  253 => 
  array (
    'key' => 'Glass Antiqua',
    'val' => 'Glass Antiqua',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  254 => 
  array (
    'key' => 'Glegoo',
    'val' => 'Glegoo',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  255 => 
  array (
    'key' => 'Gloria Hallelujah',
    'val' => 'Gloria Hallelujah',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  256 => 
  array (
    'key' => 'Goblin One',
    'val' => 'Goblin One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  257 => 
  array (
    'key' => 'Gochi Hand',
    'val' => 'Gochi Hand',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  258 => 
  array (
    'key' => 'Gorditas',
    'val' => 'Gorditas',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  259 => 
  array (
    'key' => 'Goudy Bookletter 1911',
    'val' => 'Goudy Bookletter 1911',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  260 => 
  array (
    'key' => 'Graduate',
    'val' => 'Graduate',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  261 => 
  array (
    'key' => 'Grand Hotel',
    'val' => 'Grand Hotel',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  262 => 
  array (
    'key' => 'Gravitas One',
    'val' => 'Gravitas One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  263 => 
  array (
    'key' => 'Great Vibes',
    'val' => 'Great Vibes',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  264 => 
  array (
    'key' => 'Griffy',
    'val' => 'Griffy',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  265 => 
  array (
    'key' => 'Gruppo',
    'val' => 'Gruppo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  266 => 
  array (
    'key' => 'Gudea',
    'val' => 'Gudea',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  267 => 
  array (
    'key' => 'Gurajada',
    'val' => 'Gurajada',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  268 => 
  array (
    'key' => 'Habibi',
    'val' => 'Habibi',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  269 => 
  array (
    'key' => 'Halant',
    'val' => 'Halant',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
      4 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  270 => 
  array (
    'key' => 'Hammersmith One',
    'val' => 'Hammersmith One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  271 => 
  array (
    'key' => 'Hanalei',
    'val' => 'Hanalei',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  272 => 
  array (
    'key' => 'Hanalei Fill',
    'val' => 'Hanalei Fill',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  273 => 
  array (
    'key' => 'Handlee',
    'val' => 'Handlee',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  274 => 
  array (
    'key' => 'Hanuman',
    'val' => 'Hanuman',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  275 => 
  array (
    'key' => 'Happy Monkey',
    'val' => 'Happy Monkey',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  276 => 
  array (
    'key' => 'Headland One',
    'val' => 'Headland One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  277 => 
  array (
    'key' => 'Henny Penny',
    'val' => 'Henny Penny',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  278 => 
  array (
    'key' => 'Herr Von Muellerhoff',
    'val' => 'Herr Von Muellerhoff',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  279 => 
  array (
    'key' => 'Hind',
    'val' => 'Hind',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
      4 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  280 => 
  array (
    'key' => 'Holtwood One SC',
    'val' => 'Holtwood One SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  281 => 
  array (
    'key' => 'Homemade Apple',
    'val' => 'Homemade Apple',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  282 => 
  array (
    'key' => 'Homenaje',
    'val' => 'Homenaje',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  283 => 
  array (
    'key' => 'IM Fell DW Pica',
    'val' => 'IM Fell DW Pica',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  284 => 
  array (
    'key' => 'IM Fell DW Pica SC',
    'val' => 'IM Fell DW Pica SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  285 => 
  array (
    'key' => 'IM Fell Double Pica',
    'val' => 'IM Fell Double Pica',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  286 => 
  array (
    'key' => 'IM Fell Double Pica SC',
    'val' => 'IM Fell Double Pica SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  287 => 
  array (
    'key' => 'IM Fell English',
    'val' => 'IM Fell English',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  288 => 
  array (
    'key' => 'IM Fell English SC',
    'val' => 'IM Fell English SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  289 => 
  array (
    'key' => 'IM Fell French Canon',
    'val' => 'IM Fell French Canon',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  290 => 
  array (
    'key' => 'IM Fell French Canon SC',
    'val' => 'IM Fell French Canon SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  291 => 
  array (
    'key' => 'IM Fell Great Primer',
    'val' => 'IM Fell Great Primer',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  292 => 
  array (
    'key' => 'IM Fell Great Primer SC',
    'val' => 'IM Fell Great Primer SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  293 => 
  array (
    'key' => 'Iceberg',
    'val' => 'Iceberg',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  294 => 
  array (
    'key' => 'Iceland',
    'val' => 'Iceland',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  295 => 
  array (
    'key' => 'Imprima',
    'val' => 'Imprima',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  296 => 
  array (
    'key' => 'Inconsolata',
    'val' => 'Inconsolata',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  297 => 
  array (
    'key' => 'Inder',
    'val' => 'Inder',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  298 => 
  array (
    'key' => 'Indie Flower',
    'val' => 'Indie Flower',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  299 => 
  array (
    'key' => 'Inika',
    'val' => 'Inika',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  300 => 
  array (
    'key' => 'Irish Grover',
    'val' => 'Irish Grover',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  301 => 
  array (
    'key' => 'Istok Web',
    'val' => 'Istok Web',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  302 => 
  array (
    'key' => 'Italiana',
    'val' => 'Italiana',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  303 => 
  array (
    'key' => 'Italianno',
    'val' => 'Italianno',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  304 => 
  array (
    'key' => 'Jacques Francois',
    'val' => 'Jacques Francois',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  305 => 
  array (
    'key' => 'Jacques Francois Shadow',
    'val' => 'Jacques Francois Shadow',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  306 => 
  array (
    'key' => 'Jim Nightshade',
    'val' => 'Jim Nightshade',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  307 => 
  array (
    'key' => 'Jockey One',
    'val' => 'Jockey One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  308 => 
  array (
    'key' => 'Jolly Lodger',
    'val' => 'Jolly Lodger',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  309 => 
  array (
    'key' => 'Josefin Sans',
    'val' => 'Josefin Sans',
    'weight' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '600',
      7 => '600italic',
      8 => '700',
      9 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  310 => 
  array (
    'key' => 'Josefin Slab',
    'val' => 'Josefin Slab',
    'weight' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '600',
      7 => '600italic',
      8 => '700',
      9 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  311 => 
  array (
    'key' => 'Joti One',
    'val' => 'Joti One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  312 => 
  array (
    'key' => 'Judson',
    'val' => 'Judson',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  313 => 
  array (
    'key' => 'Julee',
    'val' => 'Julee',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  314 => 
  array (
    'key' => 'Julius Sans One',
    'val' => 'Julius Sans One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  315 => 
  array (
    'key' => 'Junge',
    'val' => 'Junge',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  316 => 
  array (
    'key' => 'Jura',
    'val' => 'Jura',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'cyrillic-ext',
    ),
  ),
  317 => 
  array (
    'key' => 'Just Another Hand',
    'val' => 'Just Another Hand',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  318 => 
  array (
    'key' => 'Just Me Again Down Here',
    'val' => 'Just Me Again Down Here',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  319 => 
  array (
    'key' => 'Kalam',
    'val' => 'Kalam',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  320 => 
  array (
    'key' => 'Kameron',
    'val' => 'Kameron',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  321 => 
  array (
    'key' => 'Kantumruy',
    'val' => 'Kantumruy',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  322 => 
  array (
    'key' => 'Karla',
    'val' => 'Karla',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  323 => 
  array (
    'key' => 'Karma',
    'val' => 'Karma',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
      4 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  324 => 
  array (
    'key' => 'Kaushan Script',
    'val' => 'Kaushan Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  325 => 
  array (
    'key' => 'Kavoon',
    'val' => 'Kavoon',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  326 => 
  array (
    'key' => 'Kdam Thmor',
    'val' => 'Kdam Thmor',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  327 => 
  array (
    'key' => 'Keania One',
    'val' => 'Keania One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  328 => 
  array (
    'key' => 'Kelly Slab',
    'val' => 'Kelly Slab',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  329 => 
  array (
    'key' => 'Kenia',
    'val' => 'Kenia',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  330 => 
  array (
    'key' => 'Khand',
    'val' => 'Khand',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
      4 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  331 => 
  array (
    'key' => 'Khmer',
    'val' => 'Khmer',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  332 => 
  array (
    'key' => 'Khula',
    'val' => 'Khula',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '600',
      3 => '700',
      4 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  333 => 
  array (
    'key' => 'Kite One',
    'val' => 'Kite One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  334 => 
  array (
    'key' => 'Knewave',
    'val' => 'Knewave',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  335 => 
  array (
    'key' => 'Kotta One',
    'val' => 'Kotta One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  336 => 
  array (
    'key' => 'Koulen',
    'val' => 'Koulen',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  337 => 
  array (
    'key' => 'Kranky',
    'val' => 'Kranky',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  338 => 
  array (
    'key' => 'Kreon',
    'val' => 'Kreon',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  339 => 
  array (
    'key' => 'Kristi',
    'val' => 'Kristi',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  340 => 
  array (
    'key' => 'Krona One',
    'val' => 'Krona One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  341 => 
  array (
    'key' => 'La Belle Aurore',
    'val' => 'La Belle Aurore',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  342 => 
  array (
    'key' => 'Laila',
    'val' => 'Laila',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
      4 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  343 => 
  array (
    'key' => 'Lakki Reddy',
    'val' => 'Lakki Reddy',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  344 => 
  array (
    'key' => 'Lancelot',
    'val' => 'Lancelot',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  345 => 
  array (
    'key' => 'Lato',
    'val' => 'Lato',
    'weight' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '700',
      7 => '700italic',
      8 => '900',
      9 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  346 => 
  array (
    'key' => 'League Script',
    'val' => 'League Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  347 => 
  array (
    'key' => 'Leckerli One',
    'val' => 'Leckerli One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  348 => 
  array (
    'key' => 'Ledger',
    'val' => 'Ledger',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  349 => 
  array (
    'key' => 'Lekton',
    'val' => 'Lekton',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  350 => 
  array (
    'key' => 'Lemon',
    'val' => 'Lemon',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  351 => 
  array (
    'key' => 'Libre Baskerville',
    'val' => 'Libre Baskerville',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  352 => 
  array (
    'key' => 'Life Savers',
    'val' => 'Life Savers',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  353 => 
  array (
    'key' => 'Lilita One',
    'val' => 'Lilita One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  354 => 
  array (
    'key' => 'Lily Script One',
    'val' => 'Lily Script One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  355 => 
  array (
    'key' => 'Limelight',
    'val' => 'Limelight',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  356 => 
  array (
    'key' => 'Linden Hill',
    'val' => 'Linden Hill',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  357 => 
  array (
    'key' => 'Lobster',
    'val' => 'Lobster',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  358 => 
  array (
    'key' => 'Lobster Two',
    'val' => 'Lobster Two',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  359 => 
  array (
    'key' => 'Londrina Outline',
    'val' => 'Londrina Outline',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  360 => 
  array (
    'key' => 'Londrina Shadow',
    'val' => 'Londrina Shadow',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  361 => 
  array (
    'key' => 'Londrina Sketch',
    'val' => 'Londrina Sketch',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  362 => 
  array (
    'key' => 'Londrina Solid',
    'val' => 'Londrina Solid',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  363 => 
  array (
    'key' => 'Lora',
    'val' => 'Lora',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  364 => 
  array (
    'key' => 'Love Ya Like A Sister',
    'val' => 'Love Ya Like A Sister',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  365 => 
  array (
    'key' => 'Loved by the King',
    'val' => 'Loved by the King',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  366 => 
  array (
    'key' => 'Lovers Quarrel',
    'val' => 'Lovers Quarrel',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  367 => 
  array (
    'key' => 'Luckiest Guy',
    'val' => 'Luckiest Guy',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  368 => 
  array (
    'key' => 'Lusitana',
    'val' => 'Lusitana',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  369 => 
  array (
    'key' => 'Lustria',
    'val' => 'Lustria',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  370 => 
  array (
    'key' => 'Macondo',
    'val' => 'Macondo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  371 => 
  array (
    'key' => 'Macondo Swash Caps',
    'val' => 'Macondo Swash Caps',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  372 => 
  array (
    'key' => 'Magra',
    'val' => 'Magra',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  373 => 
  array (
    'key' => 'Maiden Orange',
    'val' => 'Maiden Orange',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  374 => 
  array (
    'key' => 'Mako',
    'val' => 'Mako',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  375 => 
  array (
    'key' => 'Mallanna',
    'val' => 'Mallanna',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  376 => 
  array (
    'key' => 'Mandali',
    'val' => 'Mandali',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  377 => 
  array (
    'key' => 'Marcellus',
    'val' => 'Marcellus',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  378 => 
  array (
    'key' => 'Marcellus SC',
    'val' => 'Marcellus SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  379 => 
  array (
    'key' => 'Marck Script',
    'val' => 'Marck Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  380 => 
  array (
    'key' => 'Margarine',
    'val' => 'Margarine',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  381 => 
  array (
    'key' => 'Marko One',
    'val' => 'Marko One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  382 => 
  array (
    'key' => 'Marmelad',
    'val' => 'Marmelad',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  383 => 
  array (
    'key' => 'Marvel',
    'val' => 'Marvel',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  384 => 
  array (
    'key' => 'Mate',
    'val' => 'Mate',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  385 => 
  array (
    'key' => 'Mate SC',
    'val' => 'Mate SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  386 => 
  array (
    'key' => 'Maven Pro',
    'val' => 'Maven Pro',
    'weight' => 
    array (
      0 => 'regular',
      1 => '500',
      2 => '700',
      3 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  387 => 
  array (
    'key' => 'McLaren',
    'val' => 'McLaren',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  388 => 
  array (
    'key' => 'Meddon',
    'val' => 'Meddon',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  389 => 
  array (
    'key' => 'MedievalSharp',
    'val' => 'MedievalSharp',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  390 => 
  array (
    'key' => 'Medula One',
    'val' => 'Medula One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  391 => 
  array (
    'key' => 'Megrim',
    'val' => 'Megrim',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  392 => 
  array (
    'key' => 'Meie Script',
    'val' => 'Meie Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  393 => 
  array (
    'key' => 'Merienda',
    'val' => 'Merienda',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  394 => 
  array (
    'key' => 'Merienda One',
    'val' => 'Merienda One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  395 => 
  array (
    'key' => 'Merriweather',
    'val' => 'Merriweather',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
      6 => '900',
      7 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  396 => 
  array (
    'key' => 'Merriweather Sans',
    'val' => 'Merriweather Sans',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
      6 => '800',
      7 => '800italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  397 => 
  array (
    'key' => 'Metal',
    'val' => 'Metal',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  398 => 
  array (
    'key' => 'Metal Mania',
    'val' => 'Metal Mania',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  399 => 
  array (
    'key' => 'Metamorphous',
    'val' => 'Metamorphous',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  400 => 
  array (
    'key' => 'Metrophobic',
    'val' => 'Metrophobic',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  401 => 
  array (
    'key' => 'Michroma',
    'val' => 'Michroma',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  402 => 
  array (
    'key' => 'Milonga',
    'val' => 'Milonga',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  403 => 
  array (
    'key' => 'Miltonian',
    'val' => 'Miltonian',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  404 => 
  array (
    'key' => 'Miltonian Tattoo',
    'val' => 'Miltonian Tattoo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  405 => 
  array (
    'key' => 'Miniver',
    'val' => 'Miniver',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  406 => 
  array (
    'key' => 'Miss Fajardose',
    'val' => 'Miss Fajardose',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  407 => 
  array (
    'key' => 'Modern Antiqua',
    'val' => 'Modern Antiqua',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  408 => 
  array (
    'key' => 'Molengo',
    'val' => 'Molengo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  409 => 
  array (
    'key' => 'Molle',
    'val' => 'Molle',
    'weight' => 
    array (
      0 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  410 => 
  array (
    'key' => 'Monda',
    'val' => 'Monda',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  411 => 
  array (
    'key' => 'Monofett',
    'val' => 'Monofett',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  412 => 
  array (
    'key' => 'Monoton',
    'val' => 'Monoton',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  413 => 
  array (
    'key' => 'Monsieur La Doulaise',
    'val' => 'Monsieur La Doulaise',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  414 => 
  array (
    'key' => 'Montaga',
    'val' => 'Montaga',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  415 => 
  array (
    'key' => 'Montez',
    'val' => 'Montez',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  416 => 
  array (
    'key' => 'Montserrat',
    'val' => 'Montserrat',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  417 => 
  array (
    'key' => 'Montserrat Alternates',
    'val' => 'Montserrat Alternates',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  418 => 
  array (
    'key' => 'Montserrat Subrayada',
    'val' => 'Montserrat Subrayada',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  419 => 
  array (
    'key' => 'Moul',
    'val' => 'Moul',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  420 => 
  array (
    'key' => 'Moulpali',
    'val' => 'Moulpali',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  421 => 
  array (
    'key' => 'Mountains of Christmas',
    'val' => 'Mountains of Christmas',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  422 => 
  array (
    'key' => 'Mouse Memoirs',
    'val' => 'Mouse Memoirs',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  423 => 
  array (
    'key' => 'Mr Bedfort',
    'val' => 'Mr Bedfort',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  424 => 
  array (
    'key' => 'Mr Dafoe',
    'val' => 'Mr Dafoe',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  425 => 
  array (
    'key' => 'Mr De Haviland',
    'val' => 'Mr De Haviland',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  426 => 
  array (
    'key' => 'Mrs Saint Delafield',
    'val' => 'Mrs Saint Delafield',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  427 => 
  array (
    'key' => 'Mrs Sheppards',
    'val' => 'Mrs Sheppards',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  428 => 
  array (
    'key' => 'Muli',
    'val' => 'Muli',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  429 => 
  array (
    'key' => 'Mystery Quest',
    'val' => 'Mystery Quest',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  430 => 
  array (
    'key' => 'NTR',
    'val' => 'NTR',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  431 => 
  array (
    'key' => 'Neucha',
    'val' => 'Neucha',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'cyrillic',
    ),
  ),
  432 => 
  array (
    'key' => 'Neuton',
    'val' => 'Neuton',
    'weight' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  433 => 
  array (
    'key' => 'New Rocker',
    'val' => 'New Rocker',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  434 => 
  array (
    'key' => 'News Cycle',
    'val' => 'News Cycle',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  435 => 
  array (
    'key' => 'Niconne',
    'val' => 'Niconne',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  436 => 
  array (
    'key' => 'Nixie One',
    'val' => 'Nixie One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  437 => 
  array (
    'key' => 'Nobile',
    'val' => 'Nobile',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  438 => 
  array (
    'key' => 'Nokora',
    'val' => 'Nokora',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  439 => 
  array (
    'key' => 'Norican',
    'val' => 'Norican',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  440 => 
  array (
    'key' => 'Nosifer',
    'val' => 'Nosifer',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  441 => 
  array (
    'key' => 'Nothing You Could Do',
    'val' => 'Nothing You Could Do',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  442 => 
  array (
    'key' => 'Noticia Text',
    'val' => 'Noticia Text',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'vietnamese',
    ),
  ),
  443 => 
  array (
    'key' => 'Noto Sans',
    'val' => 'Noto Sans',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
      7 => 'devanagari',
    ),
  ),
  444 => 
  array (
    'key' => 'Noto Serif',
    'val' => 'Noto Serif',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
    ),
  ),
  445 => 
  array (
    'key' => 'Nova Cut',
    'val' => 'Nova Cut',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  446 => 
  array (
    'key' => 'Nova Flat',
    'val' => 'Nova Flat',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  447 => 
  array (
    'key' => 'Nova Mono',
    'val' => 'Nova Mono',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin',
    ),
  ),
  448 => 
  array (
    'key' => 'Nova Oval',
    'val' => 'Nova Oval',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  449 => 
  array (
    'key' => 'Nova Round',
    'val' => 'Nova Round',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  450 => 
  array (
    'key' => 'Nova Script',
    'val' => 'Nova Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  451 => 
  array (
    'key' => 'Nova Slim',
    'val' => 'Nova Slim',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  452 => 
  array (
    'key' => 'Nova Square',
    'val' => 'Nova Square',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  453 => 
  array (
    'key' => 'Numans',
    'val' => 'Numans',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  454 => 
  array (
    'key' => 'Nunito',
    'val' => 'Nunito',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  455 => 
  array (
    'key' => 'Odor Mean Chey',
    'val' => 'Odor Mean Chey',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  456 => 
  array (
    'key' => 'Offside',
    'val' => 'Offside',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  457 => 
  array (
    'key' => 'Old Standard TT',
    'val' => 'Old Standard TT',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  458 => 
  array (
    'key' => 'Oldenburg',
    'val' => 'Oldenburg',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  459 => 
  array (
    'key' => 'Oleo Script',
    'val' => 'Oleo Script',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  460 => 
  array (
    'key' => 'Oleo Script Swash Caps',
    'val' => 'Oleo Script Swash Caps',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  461 => 
  array (
    'key' => 'Open Sans',
    'val' => 'Open Sans',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '600',
      5 => '600italic',
      6 => '700',
      7 => '700italic',
      8 => '800',
      9 => '800italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
      7 => 'devanagari',
    ),
  ),
  462 => 
  array (
    'key' => 'Open Sans Condensed',
    'val' => 'Open Sans Condensed',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
    ),
  ),
  463 => 
  array (
    'key' => 'Oranienbaum',
    'val' => 'Oranienbaum',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  464 => 
  array (
    'key' => 'Orbitron',
    'val' => 'Orbitron',
    'weight' => 
    array (
      0 => 'regular',
      1 => '500',
      2 => '700',
      3 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  465 => 
  array (
    'key' => 'Oregano',
    'val' => 'Oregano',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  466 => 
  array (
    'key' => 'Orienta',
    'val' => 'Orienta',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  467 => 
  array (
    'key' => 'Original Surfer',
    'val' => 'Original Surfer',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  468 => 
  array (
    'key' => 'Oswald',
    'val' => 'Oswald',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  469 => 
  array (
    'key' => 'Over the Rainbow',
    'val' => 'Over the Rainbow',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  470 => 
  array (
    'key' => 'Overlock',
    'val' => 'Overlock',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  471 => 
  array (
    'key' => 'Overlock SC',
    'val' => 'Overlock SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  472 => 
  array (
    'key' => 'Ovo',
    'val' => 'Ovo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  473 => 
  array (
    'key' => 'Oxygen',
    'val' => 'Oxygen',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  474 => 
  array (
    'key' => 'Oxygen Mono',
    'val' => 'Oxygen Mono',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  475 => 
  array (
    'key' => 'PT Mono',
    'val' => 'PT Mono',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  476 => 
  array (
    'key' => 'PT Sans',
    'val' => 'PT Sans',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  477 => 
  array (
    'key' => 'PT Sans Caption',
    'val' => 'PT Sans Caption',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  478 => 
  array (
    'key' => 'PT Sans Narrow',
    'val' => 'PT Sans Narrow',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  479 => 
  array (
    'key' => 'PT Serif',
    'val' => 'PT Serif',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  480 => 
  array (
    'key' => 'PT Serif Caption',
    'val' => 'PT Serif Caption',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
      3 => 'cyrillic-ext',
    ),
  ),
  481 => 
  array (
    'key' => 'Pacifico',
    'val' => 'Pacifico',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  482 => 
  array (
    'key' => 'Paprika',
    'val' => 'Paprika',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  483 => 
  array (
    'key' => 'Parisienne',
    'val' => 'Parisienne',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  484 => 
  array (
    'key' => 'Passero One',
    'val' => 'Passero One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  485 => 
  array (
    'key' => 'Passion One',
    'val' => 'Passion One',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  486 => 
  array (
    'key' => 'Pathway Gothic One',
    'val' => 'Pathway Gothic One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  487 => 
  array (
    'key' => 'Patrick Hand',
    'val' => 'Patrick Hand',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'vietnamese',
    ),
  ),
  488 => 
  array (
    'key' => 'Patrick Hand SC',
    'val' => 'Patrick Hand SC',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'vietnamese',
    ),
  ),
  489 => 
  array (
    'key' => 'Patua One',
    'val' => 'Patua One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  490 => 
  array (
    'key' => 'Paytone One',
    'val' => 'Paytone One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  491 => 
  array (
    'key' => 'Peddana',
    'val' => 'Peddana',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  492 => 
  array (
    'key' => 'Peralta',
    'val' => 'Peralta',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  493 => 
  array (
    'key' => 'Permanent Marker',
    'val' => 'Permanent Marker',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  494 => 
  array (
    'key' => 'Petit Formal Script',
    'val' => 'Petit Formal Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  495 => 
  array (
    'key' => 'Petrona',
    'val' => 'Petrona',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  496 => 
  array (
    'key' => 'Philosopher',
    'val' => 'Philosopher',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'cyrillic',
    ),
  ),
  497 => 
  array (
    'key' => 'Piedra',
    'val' => 'Piedra',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  498 => 
  array (
    'key' => 'Pinyon Script',
    'val' => 'Pinyon Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  499 => 
  array (
    'key' => 'Pirata One',
    'val' => 'Pirata One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  500 => 
  array (
    'key' => 'Plaster',
    'val' => 'Plaster',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  501 => 
  array (
    'key' => 'Play',
    'val' => 'Play',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'cyrillic-ext',
    ),
  ),
  502 => 
  array (
    'key' => 'Playball',
    'val' => 'Playball',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  503 => 
  array (
    'key' => 'Playfair Display',
    'val' => 'Playfair Display',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  504 => 
  array (
    'key' => 'Playfair Display SC',
    'val' => 'Playfair Display SC',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
      4 => '900',
      5 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  505 => 
  array (
    'key' => 'Podkova',
    'val' => 'Podkova',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  506 => 
  array (
    'key' => 'Poiret One',
    'val' => 'Poiret One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  507 => 
  array (
    'key' => 'Poller One',
    'val' => 'Poller One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  508 => 
  array (
    'key' => 'Poly',
    'val' => 'Poly',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  509 => 
  array (
    'key' => 'Pompiere',
    'val' => 'Pompiere',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  510 => 
  array (
    'key' => 'Pontano Sans',
    'val' => 'Pontano Sans',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  511 => 
  array (
    'key' => 'Port Lligat Sans',
    'val' => 'Port Lligat Sans',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  512 => 
  array (
    'key' => 'Port Lligat Slab',
    'val' => 'Port Lligat Slab',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  513 => 
  array (
    'key' => 'Prata',
    'val' => 'Prata',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  514 => 
  array (
    'key' => 'Preahvihear',
    'val' => 'Preahvihear',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  515 => 
  array (
    'key' => 'Press Start 2P',
    'val' => 'Press Start 2P',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
    ),
  ),
  516 => 
  array (
    'key' => 'Princess Sofia',
    'val' => 'Princess Sofia',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  517 => 
  array (
    'key' => 'Prociono',
    'val' => 'Prociono',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  518 => 
  array (
    'key' => 'Prosto One',
    'val' => 'Prosto One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  519 => 
  array (
    'key' => 'Puritan',
    'val' => 'Puritan',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  520 => 
  array (
    'key' => 'Purple Purse',
    'val' => 'Purple Purse',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  521 => 
  array (
    'key' => 'Quando',
    'val' => 'Quando',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  522 => 
  array (
    'key' => 'Quantico',
    'val' => 'Quantico',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  523 => 
  array (
    'key' => 'Quattrocento',
    'val' => 'Quattrocento',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  524 => 
  array (
    'key' => 'Quattrocento Sans',
    'val' => 'Quattrocento Sans',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  525 => 
  array (
    'key' => 'Questrial',
    'val' => 'Questrial',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  526 => 
  array (
    'key' => 'Quicksand',
    'val' => 'Quicksand',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  527 => 
  array (
    'key' => 'Quintessential',
    'val' => 'Quintessential',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  528 => 
  array (
    'key' => 'Qwigley',
    'val' => 'Qwigley',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  529 => 
  array (
    'key' => 'Racing Sans One',
    'val' => 'Racing Sans One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  530 => 
  array (
    'key' => 'Radley',
    'val' => 'Radley',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  531 => 
  array (
    'key' => 'Rajdhani',
    'val' => 'Rajdhani',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
      4 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  532 => 
  array (
    'key' => 'Raleway',
    'val' => 'Raleway',
    'weight' => 
    array (
      0 => '100',
      1 => '200',
      2 => '300',
      3 => 'regular',
      4 => '500',
      5 => '600',
      6 => '700',
      7 => '800',
      8 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  533 => 
  array (
    'key' => 'Raleway Dots',
    'val' => 'Raleway Dots',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  534 => 
  array (
    'key' => 'Ramabhadra',
    'val' => 'Ramabhadra',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  535 => 
  array (
    'key' => 'Ramaraja',
    'val' => 'Ramaraja',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  536 => 
  array (
    'key' => 'Rambla',
    'val' => 'Rambla',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  537 => 
  array (
    'key' => 'Rammetto One',
    'val' => 'Rammetto One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  538 => 
  array (
    'key' => 'Ranchers',
    'val' => 'Ranchers',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  539 => 
  array (
    'key' => 'Rancho',
    'val' => 'Rancho',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  540 => 
  array (
    'key' => 'Ranga',
    'val' => 'Ranga',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  541 => 
  array (
    'key' => 'Rationale',
    'val' => 'Rationale',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  542 => 
  array (
    'key' => 'Ravi Prakash',
    'val' => 'Ravi Prakash',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  543 => 
  array (
    'key' => 'Redressed',
    'val' => 'Redressed',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  544 => 
  array (
    'key' => 'Reenie Beanie',
    'val' => 'Reenie Beanie',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  545 => 
  array (
    'key' => 'Revalia',
    'val' => 'Revalia',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  546 => 
  array (
    'key' => 'Ribeye',
    'val' => 'Ribeye',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  547 => 
  array (
    'key' => 'Ribeye Marrow',
    'val' => 'Ribeye Marrow',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  548 => 
  array (
    'key' => 'Righteous',
    'val' => 'Righteous',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  549 => 
  array (
    'key' => 'Risque',
    'val' => 'Risque',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  550 => 
  array (
    'key' => 'Roboto',
    'val' => 'Roboto',
    'weight' => 
    array (
      0 => '100',
      1 => '100italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '500',
      7 => '500italic',
      8 => '700',
      9 => '700italic',
      10 => '900',
      11 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
    ),
  ),
  551 => 
  array (
    'key' => 'Roboto Condensed',
    'val' => 'Roboto Condensed',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '700',
      5 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
    ),
  ),
  552 => 
  array (
    'key' => 'Roboto Slab',
    'val' => 'Roboto Slab',
    'weight' => 
    array (
      0 => '100',
      1 => '300',
      2 => 'regular',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
    ),
  ),
  553 => 
  array (
    'key' => 'Rochester',
    'val' => 'Rochester',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  554 => 
  array (
    'key' => 'Rock Salt',
    'val' => 'Rock Salt',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  555 => 
  array (
    'key' => 'Rokkitt',
    'val' => 'Rokkitt',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  556 => 
  array (
    'key' => 'Romanesco',
    'val' => 'Romanesco',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  557 => 
  array (
    'key' => 'Ropa Sans',
    'val' => 'Ropa Sans',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  558 => 
  array (
    'key' => 'Rosario',
    'val' => 'Rosario',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  559 => 
  array (
    'key' => 'Rosarivo',
    'val' => 'Rosarivo',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  560 => 
  array (
    'key' => 'Rouge Script',
    'val' => 'Rouge Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  561 => 
  array (
    'key' => 'Rozha One',
    'val' => 'Rozha One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  562 => 
  array (
    'key' => 'Rubik Mono One',
    'val' => 'Rubik Mono One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  563 => 
  array (
    'key' => 'Rubik One',
    'val' => 'Rubik One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  564 => 
  array (
    'key' => 'Ruda',
    'val' => 'Ruda',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  565 => 
  array (
    'key' => 'Rufina',
    'val' => 'Rufina',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  566 => 
  array (
    'key' => 'Ruge Boogie',
    'val' => 'Ruge Boogie',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  567 => 
  array (
    'key' => 'Ruluko',
    'val' => 'Ruluko',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  568 => 
  array (
    'key' => 'Rum Raisin',
    'val' => 'Rum Raisin',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  569 => 
  array (
    'key' => 'Ruslan Display',
    'val' => 'Ruslan Display',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  570 => 
  array (
    'key' => 'Russo One',
    'val' => 'Russo One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  571 => 
  array (
    'key' => 'Ruthie',
    'val' => 'Ruthie',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  572 => 
  array (
    'key' => 'Rye',
    'val' => 'Rye',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  573 => 
  array (
    'key' => 'Sacramento',
    'val' => 'Sacramento',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  574 => 
  array (
    'key' => 'Sail',
    'val' => 'Sail',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  575 => 
  array (
    'key' => 'Salsa',
    'val' => 'Salsa',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  576 => 
  array (
    'key' => 'Sanchez',
    'val' => 'Sanchez',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  577 => 
  array (
    'key' => 'Sancreek',
    'val' => 'Sancreek',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  578 => 
  array (
    'key' => 'Sansita One',
    'val' => 'Sansita One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  579 => 
  array (
    'key' => 'Sarina',
    'val' => 'Sarina',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  580 => 
  array (
    'key' => 'Sarpanch',
    'val' => 'Sarpanch',
    'weight' => 
    array (
      0 => 'regular',
      1 => '500',
      2 => '600',
      3 => '700',
      4 => '800',
      5 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  581 => 
  array (
    'key' => 'Satisfy',
    'val' => 'Satisfy',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  582 => 
  array (
    'key' => 'Scada',
    'val' => 'Scada',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  583 => 
  array (
    'key' => 'Schoolbell',
    'val' => 'Schoolbell',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  584 => 
  array (
    'key' => 'Seaweed Script',
    'val' => 'Seaweed Script',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  585 => 
  array (
    'key' => 'Sevillana',
    'val' => 'Sevillana',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  586 => 
  array (
    'key' => 'Seymour One',
    'val' => 'Seymour One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  587 => 
  array (
    'key' => 'Shadows Into Light',
    'val' => 'Shadows Into Light',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  588 => 
  array (
    'key' => 'Shadows Into Light Two',
    'val' => 'Shadows Into Light Two',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  589 => 
  array (
    'key' => 'Shanti',
    'val' => 'Shanti',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  590 => 
  array (
    'key' => 'Share',
    'val' => 'Share',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  591 => 
  array (
    'key' => 'Share Tech',
    'val' => 'Share Tech',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  592 => 
  array (
    'key' => 'Share Tech Mono',
    'val' => 'Share Tech Mono',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  593 => 
  array (
    'key' => 'Shojumaru',
    'val' => 'Shojumaru',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  594 => 
  array (
    'key' => 'Short Stack',
    'val' => 'Short Stack',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  595 => 
  array (
    'key' => 'Siemreap',
    'val' => 'Siemreap',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  596 => 
  array (
    'key' => 'Sigmar One',
    'val' => 'Sigmar One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  597 => 
  array (
    'key' => 'Signika',
    'val' => 'Signika',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '600',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  598 => 
  array (
    'key' => 'Signika Negative',
    'val' => 'Signika Negative',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '600',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  599 => 
  array (
    'key' => 'Simonetta',
    'val' => 'Simonetta',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '900',
      3 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  600 => 
  array (
    'key' => 'Sintony',
    'val' => 'Sintony',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  601 => 
  array (
    'key' => 'Sirin Stencil',
    'val' => 'Sirin Stencil',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  602 => 
  array (
    'key' => 'Six Caps',
    'val' => 'Six Caps',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  603 => 
  array (
    'key' => 'Skranji',
    'val' => 'Skranji',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  604 => 
  array (
    'key' => 'Slabo 13px',
    'val' => 'Slabo 13px',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  605 => 
  array (
    'key' => 'Slabo 27px',
    'val' => 'Slabo 27px',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  606 => 
  array (
    'key' => 'Slackey',
    'val' => 'Slackey',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  607 => 
  array (
    'key' => 'Smokum',
    'val' => 'Smokum',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  608 => 
  array (
    'key' => 'Smythe',
    'val' => 'Smythe',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  609 => 
  array (
    'key' => 'Sniglet',
    'val' => 'Sniglet',
    'weight' => 
    array (
      0 => 'regular',
      1 => '800',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  610 => 
  array (
    'key' => 'Snippet',
    'val' => 'Snippet',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  611 => 
  array (
    'key' => 'Snowburst One',
    'val' => 'Snowburst One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  612 => 
  array (
    'key' => 'Sofadi One',
    'val' => 'Sofadi One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  613 => 
  array (
    'key' => 'Sofia',
    'val' => 'Sofia',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  614 => 
  array (
    'key' => 'Sonsie One',
    'val' => 'Sonsie One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  615 => 
  array (
    'key' => 'Sorts Mill Goudy',
    'val' => 'Sorts Mill Goudy',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  616 => 
  array (
    'key' => 'Source Code Pro',
    'val' => 'Source Code Pro',
    'weight' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => '500',
      4 => '600',
      5 => '700',
      6 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  617 => 
  array (
    'key' => 'Source Sans Pro',
    'val' => 'Source Sans Pro',
    'weight' => 
    array (
      0 => '200',
      1 => '200italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '600',
      7 => '600italic',
      8 => '700',
      9 => '700italic',
      10 => '900',
      11 => '900italic',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'vietnamese',
    ),
  ),
  618 => 
  array (
    'key' => 'Source Serif Pro',
    'val' => 'Source Serif Pro',
    'weight' => 
    array (
      0 => 'regular',
      1 => '600',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  619 => 
  array (
    'key' => 'Special Elite',
    'val' => 'Special Elite',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  620 => 
  array (
    'key' => 'Spicy Rice',
    'val' => 'Spicy Rice',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  621 => 
  array (
    'key' => 'Spinnaker',
    'val' => 'Spinnaker',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  622 => 
  array (
    'key' => 'Spirax',
    'val' => 'Spirax',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  623 => 
  array (
    'key' => 'Squada One',
    'val' => 'Squada One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  624 => 
  array (
    'key' => 'Sree Krushnadevaraya',
    'val' => 'Sree Krushnadevaraya',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  625 => 
  array (
    'key' => 'Stalemate',
    'val' => 'Stalemate',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  626 => 
  array (
    'key' => 'Stalinist One',
    'val' => 'Stalinist One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  627 => 
  array (
    'key' => 'Stardos Stencil',
    'val' => 'Stardos Stencil',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  628 => 
  array (
    'key' => 'Stint Ultra Condensed',
    'val' => 'Stint Ultra Condensed',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  629 => 
  array (
    'key' => 'Stint Ultra Expanded',
    'val' => 'Stint Ultra Expanded',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  630 => 
  array (
    'key' => 'Stoke',
    'val' => 'Stoke',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  631 => 
  array (
    'key' => 'Strait',
    'val' => 'Strait',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  632 => 
  array (
    'key' => 'Sue Ellen Francisco',
    'val' => 'Sue Ellen Francisco',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  633 => 
  array (
    'key' => 'Sunshiney',
    'val' => 'Sunshiney',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  634 => 
  array (
    'key' => 'Supermercado One',
    'val' => 'Supermercado One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  635 => 
  array (
    'key' => 'Suranna',
    'val' => 'Suranna',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  636 => 
  array (
    'key' => 'Suravaram',
    'val' => 'Suravaram',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  637 => 
  array (
    'key' => 'Suwannaphum',
    'val' => 'Suwannaphum',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  638 => 
  array (
    'key' => 'Swanky and Moo Moo',
    'val' => 'Swanky and Moo Moo',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  639 => 
  array (
    'key' => 'Syncopate',
    'val' => 'Syncopate',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  640 => 
  array (
    'key' => 'Tangerine',
    'val' => 'Tangerine',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  641 => 
  array (
    'key' => 'Taprom',
    'val' => 'Taprom',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'khmer',
    ),
  ),
  642 => 
  array (
    'key' => 'Tauri',
    'val' => 'Tauri',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  643 => 
  array (
    'key' => 'Teko',
    'val' => 'Teko',
    'weight' => 
    array (
      0 => '300',
      1 => 'regular',
      2 => '500',
      3 => '600',
      4 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  644 => 
  array (
    'key' => 'Telex',
    'val' => 'Telex',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  645 => 
  array (
    'key' => 'Tenali Ramakrishna',
    'val' => 'Tenali Ramakrishna',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  646 => 
  array (
    'key' => 'Tenor Sans',
    'val' => 'Tenor Sans',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  647 => 
  array (
    'key' => 'Text Me One',
    'val' => 'Text Me One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  648 => 
  array (
    'key' => 'The Girl Next Door',
    'val' => 'The Girl Next Door',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  649 => 
  array (
    'key' => 'Tienne',
    'val' => 'Tienne',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
      2 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  650 => 
  array (
    'key' => 'Timmana',
    'val' => 'Timmana',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
      1 => 'telugu',
    ),
  ),
  651 => 
  array (
    'key' => 'Tinos',
    'val' => 'Tinos',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'vietnamese',
      6 => 'cyrillic-ext',
    ),
  ),
  652 => 
  array (
    'key' => 'Titan One',
    'val' => 'Titan One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  653 => 
  array (
    'key' => 'Titillium Web',
    'val' => 'Titillium Web',
    'weight' => 
    array (
      0 => '200',
      1 => '200italic',
      2 => '300',
      3 => '300italic',
      4 => 'regular',
      5 => 'italic',
      6 => '600',
      7 => '600italic',
      8 => '700',
      9 => '700italic',
      10 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  654 => 
  array (
    'key' => 'Trade Winds',
    'val' => 'Trade Winds',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  655 => 
  array (
    'key' => 'Trocchi',
    'val' => 'Trocchi',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  656 => 
  array (
    'key' => 'Trochut',
    'val' => 'Trochut',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  657 => 
  array (
    'key' => 'Trykker',
    'val' => 'Trykker',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  658 => 
  array (
    'key' => 'Tulpen One',
    'val' => 'Tulpen One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  659 => 
  array (
    'key' => 'Ubuntu',
    'val' => 'Ubuntu',
    'weight' => 
    array (
      0 => '300',
      1 => '300italic',
      2 => 'regular',
      3 => 'italic',
      4 => '500',
      5 => '500italic',
      6 => '700',
      7 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'cyrillic-ext',
    ),
  ),
  660 => 
  array (
    'key' => 'Ubuntu Condensed',
    'val' => 'Ubuntu Condensed',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'cyrillic-ext',
    ),
  ),
  661 => 
  array (
    'key' => 'Ubuntu Mono',
    'val' => 'Ubuntu Mono',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'greek',
      1 => 'latin-ext',
      2 => 'latin',
      3 => 'cyrillic',
      4 => 'greek-ext',
      5 => 'cyrillic-ext',
    ),
  ),
  662 => 
  array (
    'key' => 'Ultra',
    'val' => 'Ultra',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  663 => 
  array (
    'key' => 'Uncial Antiqua',
    'val' => 'Uncial Antiqua',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  664 => 
  array (
    'key' => 'Underdog',
    'val' => 'Underdog',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  665 => 
  array (
    'key' => 'Unica One',
    'val' => 'Unica One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  666 => 
  array (
    'key' => 'UnifrakturCook',
    'val' => 'UnifrakturCook',
    'weight' => 
    array (
      0 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  667 => 
  array (
    'key' => 'UnifrakturMaguntia',
    'val' => 'UnifrakturMaguntia',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  668 => 
  array (
    'key' => 'Unkempt',
    'val' => 'Unkempt',
    'weight' => 
    array (
      0 => 'regular',
      1 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  669 => 
  array (
    'key' => 'Unlock',
    'val' => 'Unlock',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  670 => 
  array (
    'key' => 'Unna',
    'val' => 'Unna',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  671 => 
  array (
    'key' => 'VT323',
    'val' => 'VT323',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  672 => 
  array (
    'key' => 'Vampiro One',
    'val' => 'Vampiro One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  673 => 
  array (
    'key' => 'Varela',
    'val' => 'Varela',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  674 => 
  array (
    'key' => 'Varela Round',
    'val' => 'Varela Round',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  675 => 
  array (
    'key' => 'Vast Shadow',
    'val' => 'Vast Shadow',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  676 => 
  array (
    'key' => 'Vesper Libre',
    'val' => 'Vesper Libre',
    'weight' => 
    array (
      0 => 'regular',
      1 => '500',
      2 => '700',
      3 => '900',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'devanagari',
    ),
  ),
  677 => 
  array (
    'key' => 'Vibur',
    'val' => 'Vibur',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  678 => 
  array (
    'key' => 'Vidaloka',
    'val' => 'Vidaloka',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  679 => 
  array (
    'key' => 'Viga',
    'val' => 'Viga',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  680 => 
  array (
    'key' => 'Voces',
    'val' => 'Voces',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  681 => 
  array (
    'key' => 'Volkhov',
    'val' => 'Volkhov',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  682 => 
  array (
    'key' => 'Vollkorn',
    'val' => 'Vollkorn',
    'weight' => 
    array (
      0 => 'regular',
      1 => 'italic',
      2 => '700',
      3 => '700italic',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  683 => 
  array (
    'key' => 'Voltaire',
    'val' => 'Voltaire',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  684 => 
  array (
    'key' => 'Waiting for the Sunrise',
    'val' => 'Waiting for the Sunrise',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  685 => 
  array (
    'key' => 'Wallpoet',
    'val' => 'Wallpoet',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  686 => 
  array (
    'key' => 'Walter Turncoat',
    'val' => 'Walter Turncoat',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  687 => 
  array (
    'key' => 'Warnes',
    'val' => 'Warnes',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  688 => 
  array (
    'key' => 'Wellfleet',
    'val' => 'Wellfleet',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  689 => 
  array (
    'key' => 'Wendy One',
    'val' => 'Wendy One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  690 => 
  array (
    'key' => 'Wire One',
    'val' => 'Wire One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  691 => 
  array (
    'key' => 'Yanone Kaffeesatz',
    'val' => 'Yanone Kaffeesatz',
    'weight' => 
    array (
      0 => '200',
      1 => '300',
      2 => 'regular',
      3 => '700',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
    ),
  ),
  692 => 
  array (
    'key' => 'Yellowtail',
    'val' => 'Yellowtail',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  693 => 
  array (
    'key' => 'Yeseva One',
    'val' => 'Yeseva One',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin-ext',
      1 => 'latin',
      2 => 'cyrillic',
    ),
  ),
  694 => 
  array (
    'key' => 'Yesteryear',
    'val' => 'Yesteryear',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
  695 => 
  array (
    'key' => 'Zeyada',
    'val' => 'Zeyada',
    'weight' => 
    array (
      0 => 'regular',
    ),
    'subsets' => 
    array (
      0 => 'latin',
    ),
  ),
);