<?php
interface Smof_Subframeworks_SubframeworkInterface{
	
	public function getData();
	
}

?>