(function($) {
  "use strict";
  
	jQuery(document).ready(function ($) {
		 $(".toggle").click(function () {
			$(this).closest( '.smof-toggle').find( '.body' ).toggle("blind");
			if ($(this).hasClass('toggle-more')) {
				$(this).removeClass("toggle-more");
			} else {
				$(this).addClass("toggle-more");
			}
		});
	});
	
})(jQuery);

var SmofEvents = function(){
	
}

SmofEvents.getPrefix = function( prefix ){
	
	var query = jQuery('html');
	
	if( prefix ){
	
		var type = typeof prefix;
		
		if( type == 'string' ){
			query = jQuery( prefix );

		}else if( prefix.nodeType ){
			query = jQuery( prefix );

		}else if( type == 'object' ){
			query = prefix;

		}
		
	}
		
	return query;

}


SmofEvents.add = function( prefix ){
	
	prefix = SmofEvents.getPrefix( prefix );
	
	SmofColor.addEvent( prefix );
	SmofCombobox.addEvent( prefix );
	SmofImageSelect.addEvent( prefix );
	SmofSliderui.addEvent( prefix );
	SmofSwitch.addEvent( prefix );
	SmofFieldTypography.addEvent( prefix );
	SmofUpload.addEvent( prefix );
	SmofRepeatable.addEvent( prefix );
}