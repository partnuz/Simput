<?php

return 	array(
	'Arial' => 'Arial' ,
	'Times New Roman' => 'Times New Roman',
	'Verdana' => 'Verdana',
)

?>